
# user-management-system
Basic user management system(CRUD) build using node Js and express Js

![alt text](https://github.com/FaizAlam/user-management-system/blob/master/Images/Img1.png?raw=true)
![alt text](https://github.com/FaizAlam/user-management-system/blob/master/Images/Img2.png?raw=true)
![alt text](https://github.com/FaizAlam/user-management-system/blob/master/Images/Img3.png?raw=true)

#### To Run this project Clone it and install modules using
```
npm install
```

Then Create .env file and create PORT and MONGO_URI Variable and specify Value.
That's it. You are ready to go. To execute this project just type
```
npm start
```


